﻿
namespace yhteystiedotProjekti
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonMinimoi = new System.Windows.Forms.Button();
            this.buttonSulje = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.kayttajanimi = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(49)))), ((int)(((byte)(63)))));
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(3, 94);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1040, 470);
            this.panel2.TabIndex = 0;
            // 
            // buttonMinimoi
            // 
            this.buttonMinimoi.BackColor = System.Drawing.Color.Transparent;
            this.buttonMinimoi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonMinimoi.Location = new System.Drawing.Point(3, 0);
            this.buttonMinimoi.Name = "buttonMinimoi";
            this.buttonMinimoi.Size = new System.Drawing.Size(94, 94);
            this.buttonMinimoi.TabIndex = 0;
            this.buttonMinimoi.UseVisualStyleBackColor = false;
            this.buttonMinimoi.Click += new System.EventHandler(this.buttonMinimoi_Click);
            // 
            // buttonSulje
            // 
            this.buttonSulje.BackColor = System.Drawing.Color.Transparent;
            this.buttonSulje.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSulje.Location = new System.Drawing.Point(-3, 0);
            this.buttonSulje.Name = "buttonSulje";
            this.buttonSulje.Size = new System.Drawing.Size(100, 94);
            this.buttonSulje.TabIndex = 0;
            this.buttonSulje.UseVisualStyleBackColor = false;
            this.buttonSulje.Click += new System.EventHandler(this.buttonSulje_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(68)))), ((int)(((byte)(173)))));
            this.panel1.Controls.Add(this.kayttajanimi);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1046, 567);
            this.panel1.TabIndex = 1;
            // 
            // kayttajanimi
            // 
            this.kayttajanimi.AutoSize = true;
            this.kayttajanimi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.kayttajanimi.ForeColor = System.Drawing.Color.Cornsilk;
            this.kayttajanimi.Location = new System.Drawing.Point(102, 48);
            this.kayttajanimi.Name = "kayttajanimi";
            this.kayttajanimi.Size = new System.Drawing.Size(155, 16);
            this.kayttajanimi.TabIndex = 3;
            this.kayttajanimi.Text = "Tervetuloa (kayttajanimi)";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Red;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(93, 91);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.buttonSulje);
            this.panel4.Location = new System.Drawing.Point(943, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(100, 94);
            this.panel4.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.buttonMinimoi);
            this.panel3.Location = new System.Drawing.Point(828, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(100, 94);
            this.panel3.TabIndex = 1;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1046, 567);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonMinimoi;
        private System.Windows.Forms.Button buttonSulje;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label kayttajanimi;
    }
}